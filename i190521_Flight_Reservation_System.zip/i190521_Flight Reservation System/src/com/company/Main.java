package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {
        char c;
        int choice1;
        Scanner sc = new Scanner(System.in);
        Passenger P = new Passenger();
        System.out.println("\n                     ---------Welcome To Flight Reservation System---------");
        System.out.println("Please, Login to the System");

        System.out.print("Enter your Phone No:");
        P.Phone_no = sc.next();

        System.out.print("Enter your 5-digit Password:");
        P.Password = sc.nextInt();

        System.out.println("Please, enter any of the following options :");
        System.out.println("1. Book a Flight");
        System.out.println("2. Cancel a Flight");
        System.out.println("3. Print Ticket");
        System.out.println("4. Exit");
        choice1 = sc.nextInt();

        if(choice1 == 1)
        {


            System.out.println("Enter your Date of Journey (DD/MM/YYYY)");
            P.flight_date = sc.next();

            System.out.println("\n\n               Available Flights");

            System.out.println("\nInternational Flights :");
            System.out.println("1.London   2. Dubai   3.New York   4.Abu Dhabi   5.SingaPore");

            System.out.println("\nDomestic Flights :");
            System.out.println("1.Karachi   2. Islamabad   3. Lahore   4.Multan   5. Bahawal Pur");

            System.out.println("\nEnter, Origin from Above mentioned :");
            P.origin = sc.next();

            System.out.println("Enter, Destination from Above mentioned :");
            P.destination = sc.next();

            System.out.println("\n\n\t\t\t\t\t\t\t\t\t\t\t\tFlights Found" );
            System.out.println("Airline              Departure          Arrival          Business Class     First Class        Economy Class");


            //Reading Available Flights from the File
            String FileName = "AvailableFlightsDetails.txt";
            File myfile = new File(FileName);
            String data;
            int no=1;
            try
            {
                Scanner sc1 = new Scanner(myfile);
                while (sc1.hasNextLine())
                {

                    data = sc1.nextLine();
                    String[] splitted_data = data.split("/");
                    System.out.println(no+"."+splitted_data[0]+"\t "+splitted_data[1]+"            "+splitted_data[2]+"          "+splitted_data[3]+"          "
                                      +splitted_data[4]+"          "+splitted_data[5]);

                    no++;

                }
                sc1.close();

            }
            catch (FileNotFoundException e)
            {
                System.out.println("File not read.");
                e.printStackTrace();
            }

            int choice2;
            System.out.print("Enter your choice : ");
            choice2 = sc.nextInt();



        }


    }
}
