package com.company;

public class Passenger {
    public
        String origin;
        String destination;
        int no_of_passengers;
        String flight_date;
        String Name;
        char gender;
        int age;
        String address;
        int passport_no;
        String travel_class;
        String Phone_no;
        int Password;

        Passenger()
        {
            origin = null;
            destination = null;
            no_of_passengers = 0;
            flight_date = null;
            Name = null;
            gender = '\0';
            age = 0;
            address = null;
            passport_no = 0;
            travel_class  = null;
            Phone_no = null;
            Password = 0;
        }

    Passenger(String origin, String destination, int no_of_passengers, String flight_date, String Name, char gender, int age, String  address, int passport_no, String travel_class, String Phone_no, int Password)
    {
        this.origin = origin;
        this.destination = destination;
        this.no_of_passengers = no_of_passengers;
        this.flight_date = flight_date;
        this.Name = Name;
        this.gender = gender;
        this.age = age;
        this.address = address;
        this.passport_no = passport_no;
        this.travel_class  = travel_class;
        this.Phone_no = Phone_no;
        this.Password = Password;
    }


}

