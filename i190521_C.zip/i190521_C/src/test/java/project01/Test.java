package project01;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
